document.addEventListener("DOMContentLoaded", () => {

    initSidebar();

});